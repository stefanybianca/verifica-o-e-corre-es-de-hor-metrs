const fileInput=document.getElementById("fileInput");
const dropzone=document.getElementById("dropzone");
const fileName=document.getElementById("fileName");
const analyzeBtn=document.getElementById("analyzeBtn");
const statusEl=document.getElementById("status");
const summary=document.getElementById("summary");
const results=document.getElementById("results");
let selectedFile=null;

fileInput.addEventListener("change",()=>setFile(fileInput.files[0]));
["dragenter","dragover"].forEach(e=>dropzone.addEventListener(e,x=>{x.preventDefault();dropzone.classList.add("drag")}));
["dragleave","drop"].forEach(e=>dropzone.addEventListener(e,x=>{x.preventDefault();dropzone.classList.remove("drag")}));
dropzone.addEventListener("drop",e=>setFile(e.dataTransfer.files[0]));

function setFile(file){
  if(!file)return;
  selectedFile=file;
  fileName.textContent=file.name;
  analyzeBtn.disabled=false;
  statusEl.textContent="Arquivo pronto para análise.";
}

function normalize(v){
  return String(v??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim();
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function numberValue(v){
  if(v===null||v===undefined||String(v).trim()==="")return null;
  if(typeof v==="number")return Number.isFinite(v)?v:null;
  let s=String(v).trim();
  if(/^-?\d+,\d+$/.test(s))s=s.replace(",",".");
  else if(/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s))s=s.replace(/\./g,"").replace(",",".");
  const n=Number(s);
  return Number.isFinite(n)?n:null;
}
function formatNumber(v){return v==null?"":Number(v).toLocaleString("pt-BR",{maximumFractionDigits:2})}

function detectHeader(rows){
  const aliases={
    equipamento:["equipamento","frota"],
    inicial:["horimetro inicial","horimetro inicio"],
    final:["horimetro final","horimetro fim"]
  };
  let best=null;
  for(let r=0;r<Math.min(rows.length,25);r++){
    const values=rows[r].map(normalize), cols={};
    for(const [key,list] of Object.entries(aliases)){
      const i=values.findIndex(v=>list.includes(v));
      if(i>=0)cols[key]=i;
    }
    const score=Object.keys(cols).length;
    if(!best||score>best.score)best={row:r,cols,score};
    if(score===3)break;
  }
  return best?.score>=2?best:null;
}

analyzeBtn.addEventListener("click",async()=>{
  if(!selectedFile)return;
  statusEl.textContent="Lendo e analisando o Excel...";
  results.innerHTML="";summary.classList.add("hidden");
  try{
    const buffer=await selectedFile.arrayBuffer();
    const workbook=XLSX.read(buffer,{type:"array",cellDates:true});
    let total=0,errors=0,warnings=0,sheets=0,html="";

    for(const sheetName of workbook.SheetNames){
      const ws=workbook.Sheets[sheetName];
      const rows=XLSX.utils.sheet_to_json(ws,{header:1,defval:null,raw:true});
      const header=detectHeader(rows);
      if(!header)continue;
      sheets++;

      const c=header.cols;
      const records=[];
      for(let r=header.row+1;r<rows.length;r++){
        const row=rows[r]||[];
        const equipamento=row[c.equipamento];
        const inicial=row[c.inicial];
        const final=row[c.final];
        if([equipamento,inicial,final].every(v=>v==null||String(v).trim()===""))continue;
        records.push({line:r+1,equipamento,inicial,final});
      }

      let previousFinal=null;
      const checked=[];
      for(const rec of records){
        const ini=numberValue(rec.inicial),fim=numberValue(rec.final);
        let state="OK",note="";
        const hasInvalid=(rec.inicial!==null&&String(rec.inicial).trim()!==""&&ini===null)||(rec.final!==null&&String(rec.final).trim()!==""&&fim===null);
        if(hasInvalid){state="VERIFICAR";note="Horímetro não numérico.";warnings++}
        else if(ini!==null&&fim!==null&&fim<ini){state="ERRO";note="Horímetro final menor que o inicial.";errors++}
        else if(previousFinal!==null&&ini!==null&&ini<previousFinal){state="ERRO";note=`Inicial (${formatNumber(ini)}) menor que o final anterior (${formatNumber(previousFinal)}).`;errors++}
        else if(previousFinal!==null&&ini!==null&&ini>previousFinal){note=`Diferença desde o final anterior: ${formatNumber(ini-previousFinal)} h.`}
        total++;
        if(fim!==null)previousFinal=fim;
        checked.push({...rec,ini,fim,state,note});
      }

      html+=`<article class="sheet"><h2>${escapeHtml(sheetName)}</h2><div class="meta">Cabeçalho detectado na linha ${header.row+1} · ${checked.length} registros</div><table><thead><tr><th>Linha</th><th>Equipamento</th><th>Inicial</th><th>Final</th><th>Status</th><th>Observação</th></tr></thead><tbody>`;
      for(const x of checked){
        html+=`<tr><td>${x.line}</td><td>${escapeHtml(x.equipamento)}</td><td>${escapeHtml(x.inicial)}</td><td>${escapeHtml(x.final)}</td><td class="status-${x.state.toLowerCase()}">${x.state}</td><td>${escapeHtml(x.note)}</td></tr>`;
      }
      html+="</tbody></table></article>";
    }

    if(!sheets){
      statusEl.textContent="Nenhuma aba de horímetros foi identificada.";
      results.innerHTML=`<section class="card"><b>Não encontrei as colunas necessárias.</b><p>O leitor procura automaticamente nas primeiras 25 linhas de cada aba por Equipamento, Horímetro Inicial e Horímetro Final.</p></section>`;
      return;
    }

    summary.innerHTML=`<div class="metric"><small>Abas analisadas</small><strong>${sheets}</strong></div><div class="metric"><small>Registros</small><strong>${total}</strong></div><div class="metric"><small>Erros</small><strong class="danger">${errors}</strong></div><div class="metric"><small>Verificar</small><strong class="warning">${warnings}</strong></div>`;
    summary.classList.remove("hidden");
    results.innerHTML=html;
    statusEl.textContent=`Análise concluída. ${sheets} abas encontradas.`;
  }catch(error){
    console.error(error);
    statusEl.textContent="Não foi possível ler o arquivo.";
    results.innerHTML=`<section class="card"><b>Erro:</b> ${escapeHtml(error.message)}</section>`;
  }
});
