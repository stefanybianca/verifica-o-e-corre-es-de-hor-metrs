# Auditoria de Horímetros

Site simples para analisar arquivos Excel de registros de horímetros.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie **todos os arquivos desta pasta** para a raiz do repositório.
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e abra o endereço do GitHub Pages.

## Como funciona

O site roda no navegador e não envia o Excel para um servidor.

Ele:
- lê `.xlsx`, `.xls` e `.xlsm`;
- percorre todas as abas;
- procura os cabeçalhos nas primeiras 25 linhas;
- identifica `Equipamento`, `Horímetro Inicial` e `Horímetro Final`;
- ignora abas sem estrutura de horímetro;
- verifica final menor que inicial;
- verifica continuidade entre registros;
- mostra os resultados por aba.

A biblioteca SheetJS é carregada por CDN.
